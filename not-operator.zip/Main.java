public class Main {
    public static void main(String[] args) {

        int number = 5;

        if (!(number == 0)) {
            System.out.println("Number is not 0");
        } else {
            System.out.println("Number is 0");
        }
    }
}

