public class Main {
    public static void main(String[] args) {

        int left = 10;
        int right = 5;

        if (left > right) {
            System.out.println("Left value is greater");
        } else {
            System.out.println("Left value is NOT greater");
        }
    }
}

