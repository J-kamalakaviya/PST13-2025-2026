public class Main {
    public static void main(String[] args) {
        int number = 25;

        if (number > 10 && number < 50) {
            System.out.println("Number is greater than 10 and less than 50");
        } else {
            System.out.println("Number is not in the range");
        }
    }
}

