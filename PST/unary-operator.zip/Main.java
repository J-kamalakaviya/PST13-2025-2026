public class Main {
    public static void main(String[] args) {

        int x = 10;
        boolean flag = false;


        System.out.println(+x);

        System.out.println(-x);

        System.out.println(++x);
        
        System.out.println(x++);

        System.out.println(x);

        System.out.println(--x);

        System.out.println(x--);

        System.out.println(x);

        System.out.println(!flag);
    }
}

