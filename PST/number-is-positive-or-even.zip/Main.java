public class Main {
    public static void main(String[] args) {
        int num = 3; 

        if (num > 0 || num % 2 == 0) {
            System.out.println(num + " is positive or even");
        } else {
            System.out.println(num + " is neither positive nor even");
        }
    }
}


